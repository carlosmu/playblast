# TODO List

- Separate export files by markers, using marker name as suffix.
- Color management options, automatically use standard override
- Scene name as suffix
- Action name as suffix
- Automatic incremental version
- Rewrite all addon
- Filename in quick setting
- Redesign quick settings button
- 